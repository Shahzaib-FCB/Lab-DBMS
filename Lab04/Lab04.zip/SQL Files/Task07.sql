USE DataBase1;

SELECT sname FROM Student
WHERE major = 'Computer Science'
ORDER BY age DESC;